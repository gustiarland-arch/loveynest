/*
 * LoveyNest service worker.
 *
 * Caches only what is safe to keep on a shared phone: hashed build assets,
 * icons, and the offline page. Pages and JSON carry private data and always
 * go to the network.
 */
const VERSION = 'v4';
const STATIC_CACHE = `usandus-static-${VERSION}`;
const PRECACHE = ['/offline.html', '/offline.js', '/icons/icon-192.png', '/icons/badge-96.png', '/icons/favicon.svg'];

self.addEventListener('install', (event) => {
    event.waitUntil(caches.open(STATIC_CACHE).then((cache) => cache.addAll(PRECACHE)).then(() => self.skipWaiting()));
});

self.addEventListener('activate', (event) => {
    event.waitUntil(
        caches
            .keys()
            .then((keys) => Promise.all(keys.filter((key) => key.startsWith('usandus-') && key !== STATIC_CACHE).map((key) => caches.delete(key))))
            .then(() => self.clients.claim()),
    );
});

self.addEventListener('fetch', (event) => {
    const { request } = event;
    if (request.method !== 'GET') return;
    const url = new URL(request.url);
    if (url.origin !== self.location.origin) return;

    // Full page loads: network only, with an offline page when the server is unreachable.
    if (request.mode === 'navigate') {
        event.respondWith(fetch(request).catch(() => caches.match('/offline.html')));
        return;
    }

    // Build assets have content hashes in their names, so a cached copy never goes stale.
    if (url.pathname.startsWith('/build/assets/')) {
        event.respondWith(
            caches.match(request).then(
                (cached) =>
                    cached ||
                    fetch(request).then((response) => {
                        if (response.ok) {
                            const copy = response.clone();
                            caches.open(STATIC_CACHE).then((cache) => cache.put(request, copy));
                        }
                        return response;
                    }),
            ),
        );
        return;
    }

    // Icons keep their names across releases: show the cached one, refresh it in the background.
    if (url.pathname.startsWith('/icons/')) {
        event.respondWith(
            caches.open(STATIC_CACHE).then((cache) =>
                cache.match(request).then((cached) => {
                    const fresh = fetch(request).then((response) => {
                        if (response.ok) cache.put(request, response.clone());
                        return response;
                    });
                    return cached || fresh;
                }),
            ),
        );
        return;
    }
    // Photos and voice notes may be locked end to end: they are opened here, so <img> and <audio> work unchanged.
    if (LOCKED_MEDIA.test(url.pathname)) {
        event.respondWith(lockedMedia(request));
        return;
    }
    // Everything else (Inertia JSON, chat polling, API calls) is left to the browser.
});

/*
 * End-to-end encryption. Keys live in the IndexedDB database the app writes (resources/js/lib/e2e/store.js);
 * the formats match resources/js/lib/e2e/core.js. Opened media stays in memory only, never in a cache.
 */
const LOCKED_MEDIA = /^\/(chat\/photos\/|chat\/audio\/|photos\/\d+\/|impian\/\d+\/foto|photobooth\/foto\/)/;
const TOKEN = /e2e1:[A-Za-z0-9]{8}:[A-Za-z0-9_-]{38,}/g;
const enc = new TextEncoder();
const dec = new TextDecoder();
const opened = new Map(); // url -> { type, bytes }, a few recent ones for audio range requests

function spaceKey(keyId) {
    return new Promise((resolve) => {
        const request = indexedDB.open('loveynest-e2e', 1);
        request.onupgradeneeded = () => {
            if (!request.result.objectStoreNames.contains('kv')) request.result.createObjectStore('kv');
        };
        request.onerror = () => resolve(null);
        request.onsuccess = () => {
            const db = request.result;
            try {
                const get = db.transaction('kv', 'readonly').objectStore('kv').get(`key:${keyId}`);
                get.onsuccess = () => resolve(get.result?.key ?? null);
                get.onerror = () => resolve(null);
            } catch {
                resolve(null);
            }
        };
    });
}

async function openLockedFile(buffer) {
    const view = new Uint8Array(buffer);
    if (view.length < 18 || dec.decode(view.subarray(0, 4)) !== 'LNE1') return null;
    const keyId = dec.decode(view.subarray(5, 5 + view[4]));
    const key = await spaceKey(keyId);
    if (!key) return null;
    const iv = 5 + view[4];
    const plain = new Uint8Array(await crypto.subtle.decrypt({ name: 'AES-GCM', iv: view.subarray(iv, iv + 12), additionalData: enc.encode(`LNE1:${keyId}`) }, key, view.subarray(iv + 12)));
    return { type: dec.decode(plain.subarray(1, 1 + plain[0])), bytes: plain.subarray(1 + plain[0]) };
}

async function lockedMedia(request) {
    let file = opened.get(request.url);
    if (!file) {
        // Fetched whole and without Range: only the complete locked file can be opened.
        const response = await fetch(request.url, { credentials: 'same-origin', cache: 'no-store' });
        if (response.headers.get('X-E2E') !== '1') return response;
        try {
            file = await openLockedFile(await response.arrayBuffer());
        } catch {
            file = null;
        }
        if (!file) return new Response('Terkunci', { status: 403, headers: { 'Content-Type': 'text/plain; charset=utf-8' } });
        // Voice notes are asked for in many small ranges; pictures can be replaced under the same address, so only audio is kept.
        if (request.url.includes('/chat/audio/')) {
            opened.set(request.url, file);
            if (opened.size > 12) opened.delete(opened.keys().next().value);
        }
    }

    const total = file.bytes.length;
    const range = /bytes=(\d*)-(\d*)/.exec(request.headers.get('Range') || '');
    if (range) {
        // Safari plays audio only when ranges are answered with 206.
        const start = range[1] === '' ? Math.max(0, total - Number(range[2])) : Number(range[1]);
        const end = range[1] !== '' && range[2] !== '' ? Math.min(Number(range[2]), total - 1) : total - 1;
        if (start >= total || start > end) return new Response(null, { status: 416, headers: { 'Content-Range': `bytes */${total}` } });
        return new Response(file.bytes.slice(start, end + 1), {
            status: 206,
            headers: { 'Content-Type': file.type, 'Content-Range': `bytes ${start}-${end}/${total}`, 'Content-Length': String(end - start + 1), 'Accept-Ranges': 'bytes', 'Cache-Control': 'no-store' },
        });
    }
    return new Response(file.bytes, { headers: { 'Content-Type': file.type, 'Content-Length': String(total), 'Accept-Ranges': 'bytes', 'Cache-Control': 'no-store' } });
}

/** Opens locked text in a push message; without the key it says so instead of showing gibberish. */
async function openPushText(text) {
    if (typeof text !== 'string' || !text.includes('e2e1:')) return text;
    const tokens = [...new Set(text.match(TOKEN) || [])];
    const plain = new Map();
    for (const token of tokens) {
        const [, keyId, data] = token.split(':');
        const key = await spaceKey(keyId);
        let value = '🔒';
        if (key) {
            try {
                const raw = Uint8Array.from(atob(data.replace(/-/g, '+').replace(/_/g, '/') + '==='.slice((data.length + 3) % 4)), (c) => c.charCodeAt(0));
                value = dec.decode(await crypto.subtle.decrypt({ name: 'AES-GCM', iv: raw.subarray(0, 12), additionalData: enc.encode(`e2e1:${keyId}`) }, key, raw.subarray(12)));
            } catch {
                value = '🔒';
            }
        }
        plain.set(token, value);
    }
    const out = text.replace(TOKEN, (t) => plain.get(t) || '🔒');
    return out.length > 120 ? `${out.slice(0, 119)}…` : out;
}

self.addEventListener('push', (event) => {
    let data = {};
    try {
        data = event.data ? event.data.json() : {};
    } catch {
        data = {};
    }
    event.waitUntil(
        self.clients.matchAll({ type: 'window' }).then(async (clients) => {
            const title = (await openPushText(data.title)) || 'LoveyNest';
            const body = await openPushText(data.body || '');
            // While the app is open on screen it plays its own chime, so the banner stays quiet and goes away by itself.
            // A notification is still always shown: iOS and Chrome drop a subscription that receives pushes without one.
            const appVisible = clients.some((client) => client.visibilityState === 'visible');
            const watchingChat = data.tag === 'chat' && clients.some((client) => client.visibilityState === 'visible' && new URL(client.url).pathname === '/chat');
            const chat = data.tag === 'chat';

            await self.registration.showNotification(title, {
                body,
                tag: data.tag || undefined,
                renotify: Boolean(data.tag),
                icon: '/icons/icon-192.png',
                badge: '/icons/badge-96.png',
                lang: 'id',
                // A long, distinct buzz is what makes Android treat it as urgent and slide it down over other apps.
                vibrate: chat ? [0, 250, 120, 250] : [200, 100, 200, 100, 300],
                silent: appVisible,
                requireInteraction: false,
                timestamp: Date.now(),
                data: { url: data.url || '/dashboard' },
            });

            if (appVisible || watchingChat) {
                // Kept inside waitUntil so the worker stays alive until the banner is closed.
                await new Promise((resolve) => setTimeout(resolve, 3500));
                const list = await self.registration.getNotifications({ tag: data.tag || undefined }).catch(() => []);
                list.forEach((n) => n.close());
            }
        }),
    );
});

self.addEventListener('notificationclick', (event) => {
    event.notification.close();
    const path = event.notification.data && event.notification.data.url;
    // Only same-origin paths are opened, whatever the payload says.
    const target = new URL(typeof path === 'string' && path.startsWith('/') && !path.startsWith('//') ? path : '/dashboard', self.location.origin);

    event.waitUntil(
        self.clients.matchAll({ type: 'window', includeUncontrolled: true }).then((clients) => {
            const existing = clients.find((client) => new URL(client.url).origin === self.location.origin);
            if (existing) {
                // The open app navigates itself (keeps the session and avoids a full reload).
                existing.postMessage({ type: 'navigate', url: target.pathname + target.search });
                return existing.focus();
            }
            return self.clients.openWindow(target.href);
        }),
    );
});

// The browser rotated the subscription: tell the server about the new one.
self.addEventListener('pushsubscriptionchange', (event) => {
    event.waitUntil(
        self.clients.matchAll({ type: 'window' }).then((clients) => clients.forEach((client) => client.postMessage({ type: 'push-subscription-changed' }))),
    );
});
