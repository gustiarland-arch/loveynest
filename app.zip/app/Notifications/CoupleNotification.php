<?php

namespace App\Notifications;

use App\Models\User;
use App\Notifications\Channels\WebPushChannel;
use App\Services\Notifications\NotificationPreferences;
use App\Services\Push\WebPushSender;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueueAfterCommit;
use Illuminate\Notifications\Notification;

/**
 * Base for every LoveyNest notification. Content is computed when the
 * notification is created (plain strings, no models), so a queued push still
 * makes sense if the task or event is deleted before the worker runs.
 *
 * The in-app copy is written immediately and the push is sent right after the response,
 * and only after the surrounding transaction has committed. No queue worker is needed.
 */
abstract class CoupleNotification extends Notification implements ShouldQueueAfterCommit
{
    use Queueable;

    /** One attempt only: a retry would re-send to devices that already got it. */
    public int $tries = 1;

    abstract public function type(): string;

    /** @return array{title: string, body: string, url: string} */
    abstract protected function content(): array;

    /** Push collapse key; a newer push with the same topic replaces the older one. */
    public function topic(): ?string
    {
        return null;
    }

    /** @return list<string> */
    public function via(User $notifiable): array
    {
        $preference = app(NotificationPreferences::class)->for($notifiable, $this->type());
        $channels = [];

        if ($preference['in_app']) {
            $channels[] = 'database';
        }
        if ($preference['push'] && WebPushSender::isConfigured() && $notifiable->pushSubscriptions()->active()->exists()) {
            $channels[] = WebPushChannel::class;
        }

        return $channels;
    }

    /** @return array<string, string> */
    public function viaConnections(): array
    {
        // Both channels run in the request (push is deferred until after the response, see WebPushChannel).
        return ['database' => 'sync', WebPushChannel::class => 'sync'];
    }

    /** @return array<string, mixed> */
    public function toArray(User $notifiable): array
    {
        return ['type' => $this->type(), ...$this->content()];
    }

    /** @return array{title: string, body: string, url: string, tag: string} */
    public function toWebPush(User $notifiable): array
    {
        return [...$this->content(), 'tag' => $this->topic() ?? $this->type()];
    }

    public function databaseType(User $notifiable): string
    {
        return $this->type();
    }
}
