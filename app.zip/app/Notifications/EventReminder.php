<?php

namespace App\Notifications;

class EventReminder extends CoupleNotification
{
    public function __construct(private string $title, private string $when, private bool $shared) {}

    public function type(): string
    {
        return 'event_reminder';
    }

    protected function content(): array
    {
        return [
            'title' => $this->title,
            'body' => __($this->shared ? 'notifications.event_body_shared' : 'notifications.event_body', ['when' => $this->when]),
            'url' => '/calendar',
        ];
    }
}
