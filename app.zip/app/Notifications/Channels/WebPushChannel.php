<?php

namespace App\Notifications\Channels;

use App\Models\User;
use App\Notifications\CoupleNotification;
use App\Services\Push\WebPushSender;
use Illuminate\Support\Facades\Log;

class WebPushChannel
{
    public function __construct(private WebPushSender $sender) {}

    public function send(User $notifiable, CoupleNotification $notification): void
    {
        if ($notifiable->inQuietHours()) {
            return;
        }

        $subscriptions = $notifiable->pushSubscriptions()->active()->get();
        $payload = $notification->toWebPush($notifiable);
        $ttl = config('usandus.push.ttl.'.$notification->type(), config('usandus.push.ttl.default'));
        $topic = $notification->topic();

        // Sent right after the response, not through the queue: hosting without a queue worker or cron
        // would otherwise hold every push back (or never send it). A failure here must not break the request.
        defer(function () use ($subscriptions, $payload, $ttl, $topic) {
            try {
                $this->sender->send($subscriptions, $payload, $ttl, $topic);
            } catch (\Throwable $e) {
                Log::warning('push.send_failed', ['error' => $e::class]);
            }
        });
    }
}
