<?php

namespace App\Notifications;

class TaskReminder extends CoupleNotification
{
    public function __construct(private string $title, private string $when, private bool $shared) {}

    public function type(): string
    {
        return 'task_reminder';
    }

    protected function content(): array
    {
        return [
            'title' => $this->title,
            'body' => __($this->shared ? 'notifications.task_body_shared' : 'notifications.task_body', ['when' => $this->when]),
            'url' => $this->shared ? '/tasks?space=ours' : '/tasks',
        ];
    }
}
