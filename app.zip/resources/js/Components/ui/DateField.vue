<script setup>
import { computed, ref, useId, watch } from 'vue';
import { CalendarDays, ChevronLeft, ChevronRight } from '@lucide/vue';
import Dialog from '@/Components/ui/Dialog.vue';
import Button from '@/Components/ui/Button.vue';
import { addDaysToKey, todayKey } from '@/lib/dates';
import { t } from '@/i18n';

// Date picker as a bottom sheet. The value is always 'YYYY-MM-DD' (or '' when empty).
const model = defineModel({ type: String, default: '' });

const props = defineProps({
    label: { type: String, required: true },
    error: { type: String, default: null },
    required: { type: Boolean, default: false },
    clearable: { type: Boolean, default: false },
    disabled: { type: Boolean, default: false },
});

const id = useId();
const open = ref(false);
const today = todayKey();
const viewMonth = ref((model.value || today).slice(0, 7));

watch(open, (isOpen) => {
    if (isOpen) viewMonth.value = (model.value || today).slice(0, 7);
});

const fmt = (key, options) => new Intl.DateTimeFormat('id-ID', { timeZone: 'UTC', ...options }).format(new Date(`${key}T00:00:00Z`));
const display = computed(() => (model.value ? fmt(model.value, { weekday: 'short', day: 'numeric', month: 'short', year: 'numeric' }) : ''));
const monthTitle = computed(() => fmt(`${viewMonth.value}-01`, { month: 'long', year: 'numeric' }));
const weekdays = Array.from({ length: 7 }, (_, i) => new Intl.DateTimeFormat('id-ID', { weekday: 'short', timeZone: 'UTC' }).format(new Date(Date.UTC(2024, 0, 1 + i))));

const cells = computed(() => {
    const [y, m] = viewMonth.value.split('-').map(Number);
    const lead = (new Date(Date.UTC(y, m - 1, 1)).getUTCDay() + 6) % 7;
    const days = new Date(Date.UTC(y, m, 0)).getUTCDate();
    const start = addDaysToKey(`${viewMonth.value}-01`, -lead);
    return Array.from({ length: Math.ceil((lead + days) / 7) * 7 }, (_, i) => {
        const key = addDaysToKey(start, i);
        return { key, day: Number(key.slice(8)), inMonth: key.startsWith(viewMonth.value) };
    });
});

function shift(delta) {
    const [y, m] = viewMonth.value.split('-').map(Number);
    viewMonth.value = new Date(Date.UTC(y, m - 1 + delta, 1)).toISOString().slice(0, 7);
}

function pick(key) {
    model.value = key;
    open.value = false;
}

function clear() {
    model.value = '';
    open.value = false;
}
</script>

<template>
    <div class="space-y-1.5">
        <label :for="id" class="block text-sm font-semibold text-plum">{{ label }}<span v-if="required" class="text-danger" aria-hidden="true"> *</span></label>
        <button
            :id="id"
            type="button"
            :disabled="disabled"
            :aria-invalid="error ? 'true' : undefined"
            class="flex h-12 w-full items-center justify-between gap-2 rounded-md border bg-ivory px-3 text-left text-[0.9375rem] transition min-[400px]:px-4 min-[400px]:text-base focus:border-rose-ink focus:outline-none focus:ring-4 focus:ring-blush disabled:opacity-50"
            :class="[error ? 'border-danger' : 'border-line-strong', model ? 'text-plum' : 'text-ink-muted/70']"
            @click="open = true"
        >
            <span class="truncate">{{ display || t('picker.chooseDate') }}</span>
            <CalendarDays class="size-5 shrink-0 text-ink-muted" aria-hidden="true" />
        </button>
        <p v-if="error" class="text-xs font-medium text-danger">{{ error }}</p>

        <Dialog v-model:open="open" :title="label">
            <div class="mb-3 flex items-center justify-between">
                <button type="button" class="grid size-10 place-items-center rounded-full bg-petal text-berry-ink" :aria-label="t('calendar.prev')" @click="shift(-1)"><ChevronLeft class="size-5" aria-hidden="true" /></button>
                <p class="font-display text-lg font-semibold capitalize text-plum" aria-live="polite">{{ monthTitle }}</p>
                <button type="button" class="grid size-10 place-items-center rounded-full bg-petal text-berry-ink" :aria-label="t('calendar.next')" @click="shift(1)"><ChevronRight class="size-5" aria-hidden="true" /></button>
            </div>
            <div class="grid grid-cols-7 pb-1 text-center text-xs font-semibold text-ink-muted" aria-hidden="true">
                <span v-for="name in weekdays" :key="name">{{ name }}</span>
            </div>
            <div class="grid grid-cols-7 gap-y-1">
                <button
                    v-for="cell in cells"
                    :key="cell.key"
                    type="button"
                    :aria-pressed="model === cell.key"
                    :aria-label="fmt(cell.key, { dateStyle: 'full' })"
                    class="mx-auto grid size-11 place-items-center rounded-2xl text-base transition"
                    :class="[
                        model === cell.key ? 'bg-berry font-bold text-white' : 'hover:bg-petal',
                        cell.key === today && model !== cell.key && 'font-bold text-berry-ink ring-2 ring-berry/40',
                        model !== cell.key && (cell.inMonth ? 'text-plum' : 'text-ink-muted/50'),
                    ]"
                    @click="pick(cell.key)"
                >
                    {{ cell.day }}
                </button>
            </div>
            <template #footer>
                <Button v-if="clearable && model" variant="ghost" @click="clear">{{ t('picker.clear') }}</Button>
                <Button variant="soft" @click="pick(today)">{{ t('calendar.today') }}</Button>
            </template>
        </Dialog>
    </div>
</template>
