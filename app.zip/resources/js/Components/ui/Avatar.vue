<script setup>
import { computed } from 'vue';

const props = defineProps({
    name: { type: String, required: true },
    src: { type: String, default: null },
    size: { type: String, default: 'md' }, // sm | md | lg
    tone: { type: String, default: 'blush' }, // blush | lavender
});

const initials = computed(() =>
    props.name
        .trim()
        .split(/\s+/)
        .filter((part) => /^\p{L}/u.test(part))
        .slice(0, 2)
        .map((part) => part[0]?.toUpperCase() ?? '')
        .join(''),
);

const sizes = { sm: 'size-8 text-xs', md: 'size-11 text-sm', lg: 'size-16 text-lg', xl: 'size-20 text-2xl' };
</script>

<template>
    <span
        class="inline-grid shrink-0 place-items-center overflow-hidden rounded-full font-bold ring-[2.5px] ring-surface shadow-soft"
        :class="[sizes[size] ?? sizes.md, tone === 'lavender' ? 'bg-gradient-to-br from-[#ddd3fb] to-[#b9aaf0] text-[#463a7c]' : 'bg-gradient-to-br from-[#f8c9da] to-[#eaa3bf] text-[#7a2f4f]']"
    >
        <img v-if="src" :src="src" :alt="name" class="size-full object-cover" />
        <span v-else aria-hidden="true">{{ initials }}</span>
        <span v-if="!src" class="sr-only">{{ name }}</span>
    </span>
</template>
