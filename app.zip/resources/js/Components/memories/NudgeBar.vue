<script setup>
import { ref } from 'vue';
import { nudges } from '@/lib/nudges';
import { http, HttpError } from '@/lib/http';
import { useToast } from '@/composables/useToast';
import { t } from '@/i18n';

const props = defineProps({
    partnerName: { type: String, required: true },
    received: { type: Array, default: () => [] },
});

const toast = useToast();
const sent = ref({});

async function send(kind) {
    try {
        await http.post('/nudges', { kind });
        sent.value = { ...sent.value, [kind]: true };
        toast.success(t('nudge.sent', { name: props.partnerName }));
        setTimeout(() => (sent.value = { ...sent.value, [kind]: false }), 1800);
    } catch (error) {
        toast.error(error instanceof HttpError && error.status === 429 ? t('nudge.wait') : t('chat.offline'));
    }
}
</script>

<template>
    <div>
        <p v-if="received.length" class="mb-3 rounded-[1rem] bg-lavender px-4 py-3 text-sm text-lavender-ink">
            <template v-for="(r, i) in received" :key="r.kind">{{ i ? ', ' : '' }}{{ t(`nudge.got.${r.kind}`) }}<template v-if="r.count > 1"> ×{{ r.count }}</template></template>
        </p>
        <ul class="grid grid-cols-4 gap-2">
            <li v-for="n in nudges" :key="n.kind">
                <button
                    type="button"
                    class="glass flex w-full flex-col items-center gap-1.5 rounded-[1.125rem] px-1 py-2.5 text-[0.75rem] font-semibold text-ink-muted transition active:scale-95 hover:shadow-lift"
                    :class="sent[n.kind] && 'ring-2 ring-berry'"
                    @click="send(n.kind)"
                >
                    <span class="grid size-[1.875rem] place-items-center rounded-[0.5625rem] transition" :class="[n.tone, sent[n.kind] && 'scale-110']">
                        <component :is="n.icon" class="size-4" aria-hidden="true" />
                    </span>
                    {{ t(`nudge.label.${n.kind}`) }}
                </button>
            </li>
        </ul>
    </div>
</template>
